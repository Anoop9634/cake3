<?php
namespace App\Controller;
use App\Controller\AppController;
use Cake\Auth\DefaultPasswordHasher;
use Alt3\Tokens\RandomBytesToken;
use Cake\Mailer\Email;
use Cake\I18n\Time;

// use Cake\Network\Email\Email;

class UsersController extends AppController
{

    public function index()
    {

        $this->viewBuilder()->layout("index");
        $session = $this->request->session();
        if($session->check('Users'))
        {
            $user_session = $session->read('Users');
            $this->set('username',$user_session);
        }
    }


	public function login()
    {

    	$this->viewBuilder()->layout("index");
	 if ($this->request->is('post')) {
	 	// debug($this->request->data);die;
	 	    $email = $this->request->data["email"];
	     	$pasword = $this->request->data["password"]; 
            $this->loadModel("Users");
            // $user = $this->Users->find()->where(['email' => $email])->ANDWhere(['password' => $pasword])->first();
            $users = $this->Users->find("all", ["conditions" => ['email' => $email]]);
            // foreach ($users as $user) {
             	//debug($users);
            // }            
            $user = $users->first();
            //debug($user);
            
            if($user){
                $type = $user->type;
                if($type == '1'){   
                 	if($user){
                 		 $obj = new DefaultPasswordHasher;
                 		if ($obj->check($pasword, $user->password)) {
                            
                            $session = $this->request->session();
                            $session->write('Users', $user); 
                            $this->Flash->setSuccess('User logged in successfully.','popup');
                    		return $this->redirect(['controller' => 'Uploads','action' => 'index']);
                        }else{
                        	$this->Flash->error('email and password is incorrect');	
                        }
                    } 
                    else{
                    	$this->Flash->error('email and password is incorrect');	        	
                 	}           

                }
                else{
                    $this->Flash->error('user not found');
                    return $this->redirect(['action' => 'index']);
                }
            }else{
                $this->Flash->error('user not found');
                return $this->redirect(['action' => 'index']);
            }
        }
	}     




     public function signup()
    {

    	 $this->viewBuilder()->layout("index");
    	 if($this->request->is('post')){
    	 	// debug($this->request->data);die;
    	 	//to get password data 
            $email = $this->request->data["email"];
    	 	 $password = $this->request->data["password"];
    	 	 $cpassword = $this->request->data["confirm_password"];
           // echo $type = $this->request->data["type"]; 
            
    	 	if($password == $cpassword){
    	 		$this->loadModel("Users");
                $users = $this->Users->find("all", ["conditions" => ['email' => $email]]);
               $user= $users->first();
                //debug($user);die;
                if($user)
                {
                    $this->Flash->error('email already registered.');
                }
                else{
    	 		        $signup = $this->Users->newEntity();
    	 		        $signup = $this->Users->patchEntity($signup, $this->request->data);
                        // $this->request->data['password'] = md5($this->request->data['password']);

    	 		       if ($this->Users->save($signup)) {
                        $session = $this->request->session();
                         $session->write('Users', $signup); 
        
	                   	$this->Flash->success('The user has been saved.');
	                 	return $this->redirect(['controller'=>'Uploads','action' => 'index']);
	        	      } else {
	                   	$this->Flash->error('The user could not be saved. Please, try again.');
	        	      }
                }
	    	}else{
	    		$this->Flash->error('pasword and confirm password not same.');
	    	}

    	}

    }

     public function logout()
    {
        // Set the layout.
        $this->viewBuilder()->layout("index");
        $session=$this->request->session();
        $session->destroy();
        
        $this->Flash->error('logout successfully');
        $this->redirect(['action' => 'index']);        
    }



    public function gallery()
    {
        $this->viewBuilder()->layout("index");   
       
        $session = $this->request->session();
        if($session->check('Users'))
        {

        $id = $session->read('Users');
        $this->set('username',$id);

        }else{

            $this->Flash->error('Session has been expired.1');
            $this->redirect(['action' => 'index']);

        } 
        
    }

    public function forgetpwd()
    {

       $this->viewBuilder()->layout('index');
       if($this->request->is('post')){
            $email = $this->request->data("email");
            $query = $this->Users->find("all",['conditions' =>['email'=> $email]]);
            $getemail = $query->first();
            $email = $getemail->email; 
            $userid = $getemail->id;
           //debug($getemail); die;
            
            if (empty($getemail)) {

                $this->Flash->error(__('user not found, try again')); 
                return $this->redirect(['controller' => 'Users', 'action' => 'index']); die;
             }
           

            if($email){
            $token = md5(uniqid($userid, true));
            }
        
            $this->loadModel('Tokkens');
            $query = $this->Tokkens->find("all",['conditions' =>['email'=> $email]]);
            $getid = $query->first();
            $uid = $getid->user_id; 
            $uemail = $getid->email;

            if($uemail){
                
                $this->loadModel('Tokkens');
                $dataAr = $token;
                $userid = $uid;
                $status = 0 ;
                $a = $this->Tokkens->updateAll(['tokken_id' => $dataAr],['user_id' => $userid], ['status' => $status]);
                $this->Flash->success('please check your mail');

                }
                else if (empty($uemail)){
                    
                $this->loadModel('Tokkens');
                $dataArr = array();
                @$dataArr["user_id"] = $userid;
                @$dataArr["email"] = $email;
                @$dataArr["tokken_id"] = $token;
                @$dataArr["status"] = 0;
                $user = $this->Tokkens->newEntity();
                $user = $this->Tokkens->patchEntity($user, $dataArr);
                 if ($this->Tokkens->save($user)){
                $this->Flash->success('check your mail');
                return $this->redirect(['controller'=>'Users','action' => 'forgetpwd']);



                }
                    
                     

            }
                   
                    $emails = new Email('gmail');
                    $emails->from(['anoop.222@222222.net' => 'My Site'])
                         ->to($uemail)
                         ->subject('Test password change')
                         ->send('http://localhost/html/Anoop/test/testapp/Users/newpass/'.$token);
                         echo "Email sent";

        }
     
    }



     public function newpass()
    {
         $this->viewBuilder()->layout(""); 

        if(empty($this->request->is('post'))){ 
            $gettoken = $this->request->params['pass'];
        
            echo $gettoken[0];

            $this->loadModel('Tokkens');
            $query = $this->Tokkens->find("all",['conditions' =>['tokken_id'=> $gettoken[0]]]);
                
               $checktoken = $query->first();
              $dbtoke = $checktoken->tokken_id;
              $user_email = $checktoken->email;
              $dbuserid = $checktoken->user_id;
              $dbtime = $checktoken->date;
              $time = Time::now();

              echo $time;

              $this->set("dbemail",$user_email);
               $this->set("dbid",$dbuserid);


                 if($dbtoke){
                  
                  

                }else
                {

                    echo "token expire";
                }
        }
            if($this->request->is('post')){ 

            $id = $this->request->data["userid"];
            $email = $this->request->data["email"];
                 $npass = $this->request->data["NewPassword"];
                 $cpass = $this->request->data["confirmPassword"];
                if($npass == $cpass)
                {
                      $this->loadModel('Users');
                      //this is array data
                      $arruser = array('id' => $id, 'password' => $npass);
                      //object data
                      $user = $this->Users->get($id);
                      debug($user);
                      //patchentity is use for paching array and objcts.  
                      $user = $this->Users->patchEntity($user, $arruser);
                    if ($this->Users->save($user)){
                        $this->Flash->success('password updated');
                        return $this->redirect(['controller'=>'Users','action' => 'index']);
                    }

                }
                else{

                    echo "paswrd not match";
                }

            }
            
    }  

}