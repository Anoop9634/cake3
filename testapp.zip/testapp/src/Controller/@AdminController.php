<?php
namespace App\Controller;

use App\Controller\AppController;



class AdminController extends AppController
{
	

	public function index()
    {
		$this->render('/Admin/pages/index');
    }

    
    public function login()
	{
		$this->render('/Admin/pages/login');


    }
	

	
	public function forms()
	{
		$this->render('/Admin/pages/forms');
		
    }

    public function blank()
    {
    	$this->render('/Admin/pages/blank');
    }
	
}
