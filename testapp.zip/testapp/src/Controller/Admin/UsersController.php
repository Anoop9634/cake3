<?php
namespace App\Controller\Admin;
//namespace App\Network\Session;

use App\Controller\AppController;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Network\Session\DatabaseSession;



class UsersController extends AppController
{
     


	public function index()
    {
    	// Set the layout.
    	$this->viewBuilder()->layout("admin");
        
    }

    public function addadmin()
    {
        // Set the layout.
        $this->viewBuilder()->layout("admin");
        
    }

    
    public function login()
	{
       
		// Set the layout.
      // $this->viewBuilder()->layout("admin");
        if ($this->request->is('post')) {
           // debug($this->request->data);
            $email = $this->request->data["email"]; 
            $pass = $this->request->data["password"];
            $users = $this->Users->find("all", ["conditions" => ['email' => $email]]);
            $user = $users->first();
            @$type=$user->type;
            if(@$type =='0')
             {
                if($user){
                    $obj = new DefaultPasswordHasher;
                    if($obj->check($pass,$user->password))
                    {
                        $this->Flash->success('User logged in successfully.');
                        $session = $this->request->session();
                        $session->write('User', $user); 
                        // echo $session->read('Config.language');
                        return $this->redirect(['action' => 'forms']);
                    }else{
                        $this->Flash->error('userid and password is incorrect');    
                        
                    }



                }
             } 
             else{

                $this->Flash->error('userid and password is incorrect');
             }  

        }

    }
	
     public function logout()
    {
        // Set the layout.
        $this->viewBuilder()->layout("admin");
        $session=$this->request->session();
        $session->destroy();
        
        $this->Flash->error('logout successfully');
        $this->redirect(['action' => 'login']);        
    }
	
	public function forms()
	{
        $session = $this->request->session();
        if ($session->check('User')) {
            // Set the layout.
            $this->viewBuilder()->layout("admin");
            $session = $this->request->session();
            $sas = $session->read('User');
            //debug($sas);
            $this->set('emailsession',$sas);
        }else{
            $this->Flash->error('Session has been expired.');
            $this->redirect(['action' => 'login']);
        }
		

    }

    public function blank()
    {
    	// Set the layout.
        $this->viewBuilder()->layout("admin");
    }

     public function tables()
    {
        // Set the layout.
        $this->viewBuilder()->layout("admin");
        $session =  $this->request->session();
        if ($session->check('User')) {
            $sas = $session->read('User');
            //debug($sas);
            //$this->set('emailsession',$sas);

        $data = $this->Users->find('all');
        // $data1 = $users->first();
        // foreach ($data as $da) {
        // debug($da);
        // }

        $this->set("alldata", $data);



        }else{
            $this->Flash->error('Session has been expired.');
            $this->redirect(['action' => 'login']);
        }
        


    }
	 
     public function edit($id)
    {

    
        /*$id = base64_decode($a); 
        $user_edit = $this->Users->get($id);

       $this->set("editdata", $user_edit);
        //$this->set(compact('user_edit'));
        // debug($user_edit); */

        $id = base64_decode($id); 
        $user = $this->Users->get($id);

        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->data);
            // $user->modified = date("Y-m-d H:i:s");
            if ($this->Users->save($user)) {
                $this->Flash->success(__('User has been updated.'));
                return $this->redirect(['action' => 'tables']);
            }
            $this->Flash->error(__('Unable to update user.'));
        }

        
        // Save logic goes here
        $this->set('user', $user);
        
    }

     public function delete($a)
    {

        $id = base64_decode($a); 
        
        if($id){
       
        $user_delete = $this->Users->get($id); 
        $result = $this->Users->delete($user_delete);
       // debug($result);
               
        $this->Flash->success('User deleted');
        $this->redirect(['action' => 'tables']);

        }
        else
        {
             $this->Flash->error('Something went wrong');
        }
      
    }



    

}
