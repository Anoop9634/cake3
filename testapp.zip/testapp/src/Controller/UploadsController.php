<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Core\Configure\Engine\PhpConfig;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;

class UploadsController extends AppController
{

    public function index()
    {
    	$this->viewBuilder()->layout("index");
    	 $session = $this->request->session();
    	 if($session->check('Users'))
    	 	{

		    	$user_session = $session->read('Users');
		    	$this->set('username',$user_session);
		    	$id = $user_session->id;
		    	//debug($id);
		     	$query = $this->Uploads->find('all', [
				     'conditions' => ['Uploads.user_id' => $id ],
				     'contain' => ['Users'],
				     
				]);

		     	$data = $query->toArray();
		     	//debug($data);

		     //echo Configure::read('IMAGE_PATH');

		     }
		     else{

            $this->Flash->error('Session has been expired.');
            $this->redirect(['controller' => 'Users','action' => 'index']);

        	} 
        	 	$session = $this->request->session();
    		 	$user_id=$session->read('Users');
    	 		$id = $user_id->id;
        		$query = $this->Uploads->find('all',["conditions" => ['user_id' => $id]]);
		
    	
				$results = $query->all();
				//$data = $results->toArray();
				$data = $query->toArray();
		 		$row = array();
				foreach ($data as $image) {
		  	  		$row[] = $image;
				}
				$this->set("image",$row);	
     	
    }
     public function logout()
    {
        // Set the layout.
        $this->viewBuilder()->layout("index");
        $session=$this->request->session();
        $session->destroy();
        
        $this->Flash->error('logout successfully');
        $this->redirect(['action' => 'index']);        
    }



    public function add()
    {
    	$this->viewBuilder()->layout("index");
    	//debug($this->request->data);
    	$session = $this->request->session();
    	 $data=$session->read('Users');
    	 $id = $data->id;
    	  

//echo WWW_ROOT."files";
	
		if (!is_dir(WWW_ROOT."imgfiles")){
    	 	$dir = new Folder(WWW_ROOT."imgfiles", true, 0777);
    	 	chmod(WWW_ROOT."imgfiles", 0777);
    	}

    	if (!is_dir( WWW_ROOT."imgfiles/".$data->id)){
    	 	 $dir = new Folder(WWW_ROOT."imgfiles/".$data->id, true, 0777); 
    	 	 chmod(WWW_ROOT."imgfiles", 0777);
    	}
    		
		 $a= $this->request->data("photo");

			$file = $this->request->data["photo"]['tmp_name']; 
			$uploadfile = $id."/".$this->request->data["photo"]['name'];
			

			if(move_uploaded_file($this->request->data["photo"]['tmp_name'], WWW_ROOT."imgfiles/".$uploadfile)){        
					if ($this->request->is('post')) {
					$dataArr = array();
					$dataArr["user_id"] = $id;
					$dataArr["image"] = $uploadfile;
					$dataArr["doc"] = "";
					$dataArr["date"] = date("Y-m-d H:i:s");

		            $upload = $this->Uploads->newEntity();
			        $upload = $this->Uploads->patchEntity($upload, $dataArr);
		            // $user->modified = date("Y-m-d H:i:s");
		        	    if ($this->Uploads->save($upload)) {
		                $this->Flash->success(__('Image has been uploaded.'));
		                return $this->redirect(['action' => 'index']);
		            	}
		            	else {
          				  $this->Flash->error('The image could not be saved. Please, try again.');
       					 }
			      	}
		           
		 	}
		

   }

public function delete($delete)
    {
    	 $id = base64_decode($delete); 
        
        if($id){
       
        $user_delete = $this->Uploads->get($id); 
        $result = $this->Uploads->delete($user_delete);
       // debug($result);
               
        $this->Flash->success('Image deleted');
        $this->redirect(['action' => 'index']);

        }
        else
        {
             $this->Flash->error('Something went wrong');
        }
      
    }

}