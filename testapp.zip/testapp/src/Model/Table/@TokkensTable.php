<?php
namespace App\Model\Table;

use Cake\ORM\Table;

class TokkensTable extends Table
{
    public function initialize(array $config)
    {
	$this->belongsTo('Users', [
            'className' => 'Users'
        ]);
    }
}
