<?php
namespace App\Model\Table;

use Cake\ORM\Table;

class UploadsTable extends Table
{
    public function initialize(array $config)
    {
	$this->belongsTo('Users', [
            'className' => 'Users'
        ]);
    }
}
